package graphic;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class HelpFrame extends JFrame {
	
	private static final long serialVersionUID = 7009746366514904469L;
	
	private BufferedReader br;
	
	public HelpFrame(){
		
		super();
		try{
			br = new BufferedReader(new InputStreamReader(new FileInputStream("help.txt")));
			try{
				
				/*JPanel panel = new JPanel();
				panel.setSize(new Dimension(200, 200));
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setMinimumSize(new Dimension(200, 200));
				panel.setLayout(new GridBagLayout());
				GridBagConstraints constraints = new GridBagConstraints();
				constraints.gridx = 0;
				constraints.gridy = 0;
				constraints.anchor = GridBagConstraints.LINE_START;
				String line = br.readLine();
				while(line != null){
					
					JLabel label = new JLabel(line);
					panel.add(label, constraints);
					constraints.gridy++;
					System.out.println(constraints.gridy);
					line = br.readLine();
				}
				
				scrollPane.add(panel);
				this.add(scrollPane, BorderLayout.PAGE_START);*/
				
				this.setPreferredSize(new Dimension(640, 360));
				JPanel panel = new JPanel();
				panel.setLayout(new GridBagLayout());
				GridBagConstraints constraints = new GridBagConstraints();
				constraints.fill = GridBagConstraints.BOTH;
				constraints.weightx = 1;
				constraints.weighty = 1;
				JTextArea lines = new JTextArea();
				lines.read(br, new File("help.txt"));
				lines.setEditable(false);
				
				JScrollPane scrollPane = new JScrollPane(lines);
				panel.add(scrollPane, constraints);
				
				this.add(panel, BorderLayout.CENTER);
				this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				this.pack();
				this.setSize(this.getPreferredSize());
				this.setResizable(false);
			}
			finally{
				br.close();
			}
		}
		catch(IOException e){}
		
	}
	
}
