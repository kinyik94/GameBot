package graphic;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

import course.Bot;


public class Drawer extends JComponent{
	
	private static final long serialVersionUID = 5474637369704622503L;
	
	private Bot b;
	
	public Drawer(Bot b){
		super();
		this.b = b;
	}

	public void paint(Graphics g){
		try{
		
			super.paintComponent(g);
			
			Graphics2D graph2 = (Graphics2D)g;
			
			graph2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			
			graph2.setPaint(Color.BLACK);
			
			int width = 50;
			int height = 50;
			
			for(int j = 0; j < b.getLevel().size()[0]; j++)
				for(int i = 0; i < b.getLevel().size()[1]; i++){
					Shape drawRect = new Rectangle2D.Double(i * width, j * height, (i+1) * width, (j+1) * height);
					graph2.setPaint(b.getLevel().get(j, i).get());
					graph2.fill(drawRect);
					graph2.setPaint(Color.WHITE);
					graph2.draw(drawRect);
					if(b.getLevel().get(j, i).get().equals(Color.CYAN)){
						Shape line = new Line2D.Double(i * width, j * height, (i+1) * width, (j+1) * height);
						graph2.setPaint(Color.BLACK);
						graph2.draw(line);
						line = new Line2D.Double((i+1) * width, j * height, i * width, (j+1) * height);
						graph2.setPaint(Color.BLACK);
						graph2.draw(line);
					}
						
				}
			
			BufferedImage img = ImageIO.read(new File("bot" + b.getDir() +".png"));
			g.drawImage(img, height * b.getPosition()[1] - 15, width * b.getPosition()[0] + 1, null);

		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}
		
	}
}