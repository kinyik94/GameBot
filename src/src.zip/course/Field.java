package course;

import java.awt.Color;
import java.io.Serializable;

public class Field implements Serializable{

	private static final long serialVersionUID = -1042205459468817117L;
	
	//The Field object store it's color in String
	
	private Color color;
	
	//Initializes a newly created Field object with grey color
	
	public Field(){
		color = Color.BLACK;
	}
	
	//Initializes a newly created Field object with the given color
	
	public Field(Color color){
		this.color = color;
	}
	
	//Returns the Field object's color
	
	public Color get(){
		return color;
	}
	
	//Sets the Field object's color to the parameter
	
	public void set(Color color){
		this.color = color;
	}
	
}
