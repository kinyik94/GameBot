package course;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class UserManager {
	
	public static User user = null;
	private static HashMap<String, User> users = null;
	
	public static void register(String Name, String Pass) throws LoginException{
		if(!users.containsKey(Name)){
			users.put(Name, User.create(Name, Pass, 1));
			write();
			File dir = new File("Users");
			if(!dir.isDirectory())
				dir.mkdir();
			dir = new File("Users" + FileSystems.getDefault().getSeparator() + Name);
			dir.mkdir();
			user = users.get(Name);
		}
		else
			throw new LoginException("Username already exists!");
	}
	
	public static void rmdir(File f) {
		File[] list = f.listFiles();
			for (int i = 0; i < list.length; i++) {
			if (list[i].isDirectory()) {
				rmdir(list[i]);
			}
			else{
				list[i].delete();
			}
			f.delete();
		}
	}
	
	public static void remove(){
		File dir = new File("Users" + FileSystems.getDefault().getSeparator() + user.getName());
		if(dir.exists())
			rmdir(dir);
		users.remove(user.getName());
		user = null;
		write();
	}
	
	public static void login(String Name, String Pass) throws LoginException{
		if(!users.containsKey(Name))
			throw new LoginException("Wrong Username or Password!");
		else{
			if(users.get(Name).Login(Pass))
				user = users.get(Name);
			else
				throw new LoginException("Wrong Username or Password!");
		}
	}
	
	public static void read(){
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream("user_list"))));
			try{
				users = new HashMap<String, User>();
				String line = br.readLine();
				while (line != null){
					String[] map = new String[3];
					map = line.split(" ");
					users.put(map[0], new User(map[0], map[1], Integer.valueOf(map[2])));
					line = br.readLine();
				}
			}
			finally{
				br.close();
			}
		}
		catch(IOException e){
			users = new HashMap<String, User>();
		}
	}
	
	public static void write(){
		try{
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream("user_list"))));
			try{
				for(Map.Entry<String, User> i : users.entrySet()){
					i.getValue().write(pw);
				}
			}
			finally{
				pw.close();
			}
		}
		catch(IOException e){}
	}
	
}
