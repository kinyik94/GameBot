package command;

import graphic.GameWindow;
import graphic.LoginWindow;
import graphic.MenuWindow;

import java.awt.Color;

import course.Bot;
import course.Level;
import course.UserManager;

public class GameBot {
	
	public static final int levelNumber = 5;
	
	public static void openMenu(){
		MenuWindow.open(UserManager.user, levelNumber);
	}
	
	public static void openGame(int levelNumber){
		try{
			Bot b = Bot.read(levelNumber);
	        GameWindow.game(b);
		}
		catch(IndexOutOfBoundsException e){
			System.out.println(e.getMessage());
		}
		catch(ClassNotFoundException e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void createBot(){
		Level l = new Level(15, 15, 5, "Create functions");
		int m = 0;
		int n = 0;
		l.set(m, n++, Color.WHITE);
		
		int j = 15;
		while(j > 1){
			for(; n < (15 + j) / 2 - 1; n++){
				l.set(m, n, Color.LIGHT_GRAY);
			}
			l.set(m++, n, Color.GREEN);
			for(; m < (15 + j) / 2 - 1; m++){
				l.set(m, n, Color.LIGHT_GRAY);
			}
			l.set(m, n--, Color.GREEN);
			for(; n > (15 - j) / 2; n--){
				l.set(m, n, Color.LIGHT_GRAY);
			}
			l.set(m--, n, Color.GREEN);
			for(; m > (15 - j) / 2 + 2; m--){
				l.set(m, n, Color.LIGHT_GRAY);
			}
			if(j > 3)
				l.set(m, n++, Color.GREEN);
			j-=4;
		}
		
		l.set(m+1, n, Color.CYAN);
		int[] a = {0, 0};
		Bot b = new Bot(l, a);
		l.isFunc1 = true;
		l.isFunc2 = true;
		b.write();
	}
	
	public static void main(String[] args) {
		UserManager.read();
		LoginWindow.login();
		//createBot();
	}

}
