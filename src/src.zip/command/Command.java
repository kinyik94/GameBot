package command;

import graphic.GameWindow;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;

import course.Bot;
import course.UserManager;


public class Command {
	
	/*
	 * This class handles the commands.
	 * It checks the syntax of the code and it runs the code
	 * The SyntaxChecker() reads the commands from the file,
	 * and check the commands syntax. If the syntax good, then the function put it in the cmd List.
	 * The run method read the commands from the cmd List and execute it.
	 */
	
	
	/*
	 * The par string array stores the commands parameters
	 * The pars string is the string of the parameters, with split we get the par array
	 * Line is the input line, it contains the command and the parameters
	 * ln is the number of the line
	 * isError is a boolean value and it is true when the program found error
	 * index is the index
	 */
	private static String[] par = null;
	private static String pars;
	private static String line = "";
	public static int ln = 0;
	private static boolean isError = false;
	
	/*
	 * The ArrayList cmd stores the commands
	 * HashMap loops stores the loops and the key is the line 
	 * where the loop ends.
	 */
	
	private static ArrayList<String> cmdmain = new ArrayList<String>();
	private static ArrayList<String> cmdfunc1 = new ArrayList<String>();
	private static ArrayList<String> cmdfunc2 = new ArrayList<String>();
	private static HashMap<Integer, Loop> loops = new HashMap<Integer, Loop>();
	private static HashMap<Integer, Branching> branchings = new HashMap<Integer, Branching>();
	private static ArrayDeque<String> accesspoints = new ArrayDeque<String>();
	private static ArrayList<String> cmd = null;
	private static String cmdType = null;
	
	/*
	 * Run method
	 * Get a command from cmd and execute it
	 */
	
	public static boolean run(Bot b) throws RuntimeErrorException{
		//Get the command
		if(cmd.size() > ln){
			line = cmd.get(ln);
			ln++;
			//System.out.println(cmdType + " ln: " + ln);
		}
		//If there are no more commands return false
		else{
			if(accesspoints.isEmpty()){
				ln = 0;
				cmd.clear();
				cmdmain.clear();
				cmdfunc1.clear();
				cmdfunc2.clear();
				return false;
			}
			else{
				String access = accesspoints.pop();
				cmdType = access.substring(0, 5);
				switch(cmdType){
				case "mainf":
					cmd = cmdmain;
				break;
				case "func1":
					cmd = cmdfunc1;
				break;
				case "func2":
					cmd = cmdfunc2;
				break;
				default:
					System.out.println("No function like this in run() method");
					reset();
					throw new RuntimeException();
				}
				ln = Integer.valueOf(access.substring(5, access.length()));	
				return true;
			}
		}
		
		/*
		 * 
		 */
		
		if(line.matches("move\\(.*\\)")){
			b.move();
		}	
		else if(line.matches("turn\\(.*\\)")){
			pars = line.substring(5, line.length() - 1);
			if(pars.length() > 0){
				par = pars.split(" ");
				b.turn(par[0]);
			}
		}
		
		else if(line.matches("loop.*")){
			par = line.split(" ");
			if(par.length != 2)
				throw new RuntimeErrorException("Too much parameters for loop at line: " + ln);
			else{
				int get = Integer.parseInt(par[1]);
				if(!loops.get(get - 1).conditionIsTrue(b))
					ln = get;
			}
		}
		
		else if(line.matches("endloop")){
			ln = loops.get(ln - 1).begin;
		}
		
		else if(line.matches("fi")){}
		
		else if(line.matches("if.*")){
			par = line.split(" ");
			if(par.length != 2)
				throw new RuntimeErrorException("Too much parameters for if at line: " + ln);
			else{
				int get = Integer.parseInt(par[1]) - 1;
				if(!branchings.get(ln).conditionIsTrue(b))
					ln = get;
			}
		}
		
		else if(line.equals("function1")){
			accesspoints.add(cmdType + ln);
			cmd = cmdfunc1;
			cmdType = "func1";
			ln = 0;
		}
		
		else if(line.equals("function2")){
			accesspoints.add(cmdType + ln);
			cmd = cmdfunc2;
			cmdType = "func2";
			ln = 0;
		}
		
		else{
			cmdmain.clear();
			cmdfunc1.clear();
			cmdfunc2.clear();
			throw new RuntimeErrorException("Command not found at line: ");
		}
		
		if(b.getFieldColor().equals(Color.BLACK)){
			cmdmain.clear();
			cmdfunc1.clear();
			cmdfunc2.clear();
		}
		
		return true;
	}
	
	public static void SyntaxChecker(Bot b){
		PrintWriter pw = null;
		try{
			pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream("Users" + FileSystems.getDefault().getSeparator() + UserManager.user.getName() + FileSystems.getDefault().getSeparator() + 
					UserManager.user.getName() + "_consol", true)));
			pw.append(GameWindow.defText);
			
			for(int i = 1; i <= 3; i++){
				switch (i){
					case 1:
						cmd = cmdmain;
						cmdType = "Main";
					break;
					case 2:
						cmd = cmdfunc1;
						cmdType = "Function1";
					break;
					case 3:
						cmd = cmdfunc2;
						cmdType = "Function2";
					break;
					default:
						throw new IndexOutOfBoundsException("Unreachable code in SyntaxChacker()");
				}
			
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("Users" + FileSystems.getDefault().getSeparator() + UserManager.user.getName() + FileSystems.getDefault().getSeparator() + 
						UserManager.user.getName() + "_" + cmdType + "_" + b.getLevel().levelNumber)));
				
				ArrayDeque<Integer> loopindex = new ArrayDeque<Integer>();
				ArrayDeque<Integer> ifindex = new ArrayDeque<Integer>();
				HashMap<String, Color> colorMap = new HashMap<String, Color>();
				
				cmd.clear();
				
				colorMap.put("Green", Color.GREEN);
				colorMap.put("Yellow", Color.YELLOW);
				colorMap.put("Red", Color.RED);
				colorMap.put("Blue", Color.BLUE);
				colorMap.put("Gray", Color.LIGHT_GRAY);
				colorMap.put("Cyan", Color.CYAN);
				
				try{
					
					while(reader(br)){
						try{
							String replacedLine = line.replaceAll("\\s+", "");
							if(replacedLine.matches("move\\(.*\\)")){
								pars = replacedLine.substring(5, replacedLine.length() - 1);
								if(pars.length() > 0)
									throw new SyntaxErrorException("Too mutch parameter for move command in cmdType at line: " + ln);
								cmd.add(replacedLine);
							}
							else if(replacedLine.matches("turn\\(.*\\)")){
								pars = replacedLine.substring(5, replacedLine.length() - 1);
								if(pars.length() > 0){
									par = pars.split(" ");
									if(par.length != 1)
										throw new SyntaxErrorException("Too mutch parameter for turn command in cmdType at line: " + ln);
									if(!(par[0].equals("right")) && !(par[0].equals("left")))
										throw new SyntaxErrorException(par[0] + " is not acceptable parameter for turn command in cmdType at line: " + ln);
									cmd.add(replacedLine);
								}
							}
							else if(replacedLine.matches("for\\(.*\\)")){
								pars = replacedLine.substring(4, replacedLine.length() - 1);
								if(pars.length() == 0){
									loops.put(ln, new Loop(ln - 1, "for", 0, Color.BLACK, true));
								}
								else if(pars.length() > 0){
									par = pars.split(" ");
									if(par.length > 1)
										throw new SyntaxErrorException("Too mutch parameter for loop command in cmdType at line: " + ln);
									loops.put(ln, new Loop(ln - 1, "for", Integer.parseInt(par[0]) + 1, Color.BLACK, true));
								}
								loopindex.addFirst(ln);
								cmd.add("loop");
							}
							
							else if(replacedLine.matches("while\\(.*\\)")){
								pars = replacedLine.substring(6, replacedLine.length() - 1);
								if(pars.length() == 0){
									throw new SyntaxErrorException("No parameter for while in cmdType at line: " + ln);
								}
								else if(pars.length() > 0){
									par = pars.split(" ");
									if(par.length != 1)
										throw new SyntaxErrorException("Too mutch parameter for loop command in cmdType at line: " + ln);
									if(par[0].equals("true"))
										loops.put(ln, new Loop(ln - 1, "for", 0, Color.BLACK, true));
									else{
										if(par[0].matches("FieldIsNot.*"))
											loops.put(ln, new Loop(ln - 1, "while", 0, colorMap.get(par[0].substring(10, par[0].length())), false));
										else if(par[0].matches("FieldIs.*"))
											loops.put(ln, new Loop(ln - 1, "while", 0, colorMap.get(par[0].substring(10, par[0].length())), true));
										else
											throw new SyntaxErrorException("Not suitable parameter for while in cmdType at line: " + ln);
									}
								}
								loopindex.addFirst(ln);
								cmd.add("loop");
							}
							
							else if(replacedLine.equals("endloop")){
								if(loopindex.size() == 0)
									throw new SyntaxErrorException("More endloop, than loop starts in cmdType !");
								int li = loopindex.pop() - 1;
								Loop tmploop = loops.get(li + 1);
								loops.remove(li + 1);
								loops.put(ln - 1, new Loop(tmploop));
								cmd.set(li, "loop " + ln);
								cmd.add("endloop");
							}
							
							else if(replacedLine.matches("if\\(.*\\)")){
								pars = replacedLine.substring(3, replacedLine.length() - 1);
								if(pars.length() == 0){
									throw new SyntaxErrorException("No parameter for if in cmdType at line: " + ln);
								}
								else if(pars.length() > 0){
									par = pars.split(" ");
									if(par.length != 1)
										throw new SyntaxErrorException("Too mutch parameter for if in cmdType at line: " + ln);
									if(par[0].equals("true")){
										branchings.put(ln, new Branching(true, Color.BLACK, true));
									}
									else{
										if(par[0].matches("FieldIsNot.*"))
											branchings.put(ln, new Branching(false, colorMap.get(par[0].substring(10, par[0].length())), false));
										else if(par[0].matches("FieldIs.*"))
											branchings.put(ln, new Branching(true, colorMap.get(par[0].substring(7, par[0].length())), false));
										else
											throw new SyntaxErrorException("Not suitable parameter for if in cmdType at line: " + ln);
									}
								}
								ifindex.addFirst(ln);
								cmd.add("if");
							}
							
							else if(replacedLine.equals("fi")){
								if(ifindex.size() == 0)
									throw new SyntaxErrorException("More fi, than if statements in cmdType !");
								int li = ifindex.pop() - 1;
								cmd.set(li, "if " + ln);
								cmd.add("fi");
							}
							
							else if(replacedLine.matches("function1\\(.*\\)")){
								
								pars = replacedLine.substring(10, replacedLine.length() - 1);
								if(pars.length() > 0)
									throw new SyntaxErrorException("Too mutch parameter for if in cmdType at line: " + ln);
								cmd.add("function1");
							}
							
							else if(replacedLine.matches("function2\\(.*\\)")){
								pars = replacedLine.substring(10, replacedLine.length() - 1);
								if(pars.length() > 0)
									throw new SyntaxErrorException("Too mutch parameter for if in cmdType at line: " + ln);
								cmd.add("function2");
							}
							
							else if(line.trim().isEmpty());
							
							else
								throw new SyntaxErrorException("Command not found in cmdType at line: " + ln);
						}
						catch(SyntaxErrorException er){
							pw.append("SyntaxError: " + er.getMessage() + System.lineSeparator());
							cmd.add(line);
							isError = true;
						}
					}
					
					ln = 0;
					par = null;
					
					if(isError){
						cmdmain.clear();
						cmdfunc1.clear();
						cmdfunc2.clear();
					}
					
					if(loopindex.size() != 0)
						throw new SyntaxErrorException("More loops starts, than endloop!");
					
					if(ifindex.size() != 0)
						throw new SyntaxErrorException("More if statements, than fi!");
					
				}
				catch(SyntaxErrorException er){
					pw.append("SyntaxError: " + er.getMessage() + System.lineSeparator());
					if(loopindex.size() != 0)
						loopindex.clear();
					if(ifindex.size() != 0)
						ifindex.clear();
				}
				finally{
					br.close();	
				}
			}
			
			pw.close();
			
			cmd = cmdmain;
			cmdType = "mainf";
				
		}
		catch(IOException er){
			System.out.println(er.getCause().toString());
		}
		finally{
			if(pw != null)
				pw.close();
		}
		
	}
	
	private static boolean reader(BufferedReader br){
		try{
			
			line = br.readLine();

			if (line == null){
				return false;
			}
			else{
				ln++;
			}
			
			return true;
		}
		catch(IOException e){
				System.out.println(e.getMessage());
				return false;
		}
	}
	
	public static void reset(){
		par = null;
		line = "";
		ln = 0;
		isError = false;
		cmdmain.clear();
		cmdfunc1.clear();
		cmdfunc2.clear();
		cmd = null;
		loops.clear();
		branchings.clear();
		accesspoints.clear();
	}
	
}
