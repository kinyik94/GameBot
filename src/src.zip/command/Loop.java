package command;

import java.awt.Color;

import course.Bot;

public class Loop {
	
	public int begin;
	
	private String type;
	private int number;
	private int size;
	private Color color;
	private boolean conditionType;
	
	public Loop(Loop l){
		begin = l.begin;
		type = l.type;
		size = l.size;
		conditionType = l.conditionType;
		number = size;
		color = l.color;
		
	}
	
	public Loop(int begin, String type, int size, Color c, boolean conditionType){
		this.begin = begin;
		this.type = type;
		this.size = size;
		this.conditionType = conditionType;
		number = size;
		color = c;
	}
	
	public boolean conditionIsTrue(Bot b) throws RuntimeErrorException{
		
		if(type == "for"){
			number--;
			if(number < 0)
				number = -1;
			if(this.number == 0){
				number = size;
				return false;
			}
			else
				return true;
		}
		else if(type == "while"){
			return conditionType ^ !(b.getFieldColor().equals(color));
		}
		else
			throw new RuntimeErrorException("Cycle not found");
	}

}
