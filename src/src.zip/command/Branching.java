package command;

import java.awt.Color;

import course.Bot;

public class Branching {
	
	private boolean type;
	private boolean alwaystrue;
	private Color color;
	
	public Branching(Branching b){
		type = b.type;
		color = b.color;
	}
	
	public Branching(boolean type, Color c, boolean alwaystrue){
		this.type = type;
		this.alwaystrue = alwaystrue;
		color = c;
	}
	
	public boolean conditionIsTrue(Bot b){
		return alwaystrue || (type ^ !(b.getFieldColor().equals(color)));
	}
}
